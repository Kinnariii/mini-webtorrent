from flask import Flask, render_template, request, jsonify
import subprocess, os, requests, json, threading

app = Flask(__name__)

TRACKER_URL = "http://127.0.0.1:5000"
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file = request.files.get('file')
    if not file:
        return jsonify({"error": "No file provided"}), 400

    # Save the uploaded file
    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(file_path)

    # Run metainfo_generator.py on it
    result = subprocess.run(
        ["python", "metainfo_generator.py", file_path,
         "--tracker", f"{TRACKER_URL}/tracker"],
        capture_output=True, text=True
    )

    metainfo_path = f"{file_path}.json"
    if not os.path.exists(metainfo_path):
        return jsonify({"error": "Metainfo generation failed", "detail": result.stderr}), 500

    with open(metainfo_path) as f:
        metainfo = json.load(f)

    t = threading.Thread(target=run_seeder, args=(metainfo_path, 6881), daemon=True)
    t.start()
    return jsonify({
        "message": "File uploaded and metainfo created!",
        "file_name": file.filename,
        "file_size_kb": round(metainfo["file_size"] / 1024, 1),
        "num_pieces": len(metainfo["piece_hashes"]),
        "metainfo_file": metainfo_path,
    })

@app.route('/stats')
def stats():
    try:
        resp = requests.get(f"{TRACKER_URL}/stats", timeout=3)
        return jsonify(resp.json())
    except Exception as e:
        return jsonify({"error": f"Tracker unreachable: {e}"}), 503
    # Stores progress for active downloads: filename -> {percent, pieces_done, total_pieces, status}
download_progress = {}
def run_seeder(metainfo_path, port):
    subprocess.Popen(
        ["python", "peer.py", metainfo_path, "--port", str(port), "--seeder"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    )

def run_leecher(metainfo_path, port):
    """Runs peer.py as a leecher and tracks progress by watching the output."""
    with open(metainfo_path) as f:
        meta = json.load(f)

    file_name = meta["file_name"]
    total_pieces = len(meta["piece_hashes"])
    download_progress[file_name] = {
        "percent": 0, "pieces_done": 0,
        "total_pieces": total_pieces, "status": "downloading"
    }

    process = subprocess.Popen(
        ["python", "peer.py", metainfo_path, "--port", str(port)],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True
    )

    pieces_done = 0
    for line in process.stdout:
        # Strip ANSI escape codes before matching
        clean = line.encode('ascii', errors='ignore').decode()
        print("[DEBUG]", clean, flush=True)
        if "verified" in clean and "saved" in clean:
            pieces_done += 1
            pct = round((pieces_done / total_pieces) * 100, 1)
            download_progress[file_name] = {
                "percent": pct, "pieces_done": pieces_done,
                "total_pieces": total_pieces, "status": "downloading"
            }

    download_progress[file_name]["status"] = "done"
    download_progress[file_name]["percent"] = 100

@app.route('/download', methods=['POST'])
def start_download():
    data = request.get_json()
    metainfo_path = data.get("metainfo_path")
    port = data.get("port", 6882)

    if not metainfo_path or not os.path.exists(metainfo_path):
        return jsonify({"error": "Metainfo file not found"}), 400

    t = threading.Thread(target=run_leecher, args=(metainfo_path, port), daemon=True)
    t.start()

    with open(metainfo_path) as f:
        file_name = json.load(f)["file_name"]

    return jsonify({"message": "Download started", "file_name": file_name})

@app.route('/progress')
def progress():
    return jsonify(download_progress)

if __name__ == '__main__':
    app.run(debug=True, port=8000)